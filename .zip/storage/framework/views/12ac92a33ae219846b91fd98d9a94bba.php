<?php $__env->startSection('content'); ?>

    <section class="h-full  bg-gradient-to-br from-pink-50 to-indigo-100 p-8">
        <?php if(session('success')): ?>
            <div class="mb-4 text-green-600 text-center font-semibold">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="mb-4 text-red-600 text-center font-semibold">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <div class="grid justify-center md:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-7 ">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg border shadow-md max-w-xs md:max-w-none overflow-hidden">
                    <img class="h-56 lg:h-60 w-full object-cover" src="<?php echo e(Storage::url($book->image)); ?>" alt="" />
                    <div class="p-3">
                        <span class="text-sm font-bold text-blue-500 text-primary">Genre:  <?php echo e($book->genre->category); ?></span>
                        <h3 class="font-semibold text-xl leading-6 text-red-500 my-2">
                            <?php echo e($book->title); ?>

                        </h3>
                        <p class="paragraph-normal text-gray-600 font-bold">
                            Author: <?php echo e($book->user->name); ?>

                        </p>
                        <a class="mt-3 block" href="<?php echo e(route('books.show',$book->id)); ?>">Read More >></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
            <div class="mt-4">
                <?php echo e($books->links('vendor.pagination.tailwind')); ?>

            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\open server\new_projects\book-recomandation-system\resources\views/book/index.blade.php ENDPATH**/ ?>